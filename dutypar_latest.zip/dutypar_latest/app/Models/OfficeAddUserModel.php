<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OfficeAddUserModel extends Model
{
      protected $table = 'office_add_user';
    
}
