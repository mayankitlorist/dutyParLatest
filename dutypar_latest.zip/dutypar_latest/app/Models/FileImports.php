<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FileImports extends Model
{
    protected $table = 'new_table';
   
}
